package com.innowave.mahaulb.web.accounts.Controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.innowave.mahaulb.common.service.beans.UserBean;
import com.innowave.mahaulb.common.service.utils.JasperReportService;
import com.innowave.mahaulb.common.service.utils.NumberToWord;
import com.innowave.mahaulb.portal.utils.StringHelperUtils;
import com.innowave.mahaulb.service.accounts.beans.TtAmsReceiptBean;
import com.innowave.mahaulb.service.accounts.dto.reports.AccountReceiptDetailBean;
import com.innowave.mahaulb.service.accounts.dto.reports.AccountReciptSubBean;
import com.innowave.mahaulb.service.accounts.helper.AccountReceiptReportHelper;
import com.innowave.mahaulb.service.accounts.service.TtAmsReceiptService;


import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
/**
 *  @author Mohit
 */
@Controller
@RequestMapping("/account/receipt")
public class TtAmsReceiptController {
	
	@Autowired
	private TtAmsReceiptService ttAmsReceiptService;
	@Autowired
	JasperReportService jasperReportService;
	@Autowired
	private Environment env;
	 @Autowired
	 HttpSession httpsession;
	 
	public UserBean getSessionUser()
	{
		return  (UserBean) httpsession.getAttribute("userBeanObj");
	}

	public static final Logger logger = LoggerFactory.getLogger(TtAmsReceiptController.class);
	JasperPrint jasperPrint;
	private final String prefixURL = "receiptenter/";
	
	@RequestMapping(value="/receiptPage", method=RequestMethod.GET)
	public ModelAndView viewReceiptPage() {
		ModelAndView modelAndView = new ModelAndView(prefixURL+"master-search-receipt-entry"); 
		modelAndView.addObject("receiptTypeList", ttAmsReceiptService.getReceiptTypeBean());
		modelAndView.addObject("moduleList",ttAmsReceiptService.getModuleList());
		return modelAndView;
	}
	
	
	
	@RequestMapping(value = "/addReceipt", method = RequestMethod.GET)
	public ModelAndView viewAddReceiptPage() {
		logger.info("Add Receipt Page");
		ModelAndView modelAndView = new ModelAndView(prefixURL + "master-add-receipt-entry");
		modelAndView.addObject("receiptTypeList", ttAmsReceiptService.getReceiptTypeBean());
		modelAndView.addObject("wardList", ttAmsReceiptService.getAdministrationWardList());
		modelAndView.addObject("moduleList", ttAmsReceiptService.getModuleList().stream()
				.filter(bean -> bean.getLookupCode().equals("AMS")).collect(Collectors.toList()));
		modelAndView.addObject("accountCode", ttAmsReceiptService.getAccountCode());
		modelAndView.addObject("accountNumber", ttAmsReceiptService.getBankAccountDetails());
		modelAndView.addObject("backDatedReceiptEntry", ttAmsReceiptService.getBackDatedEntryDays());
		return modelAndView;
	}
	
	@RequestMapping(value="/saveReceipt",method=RequestMethod.POST)
	public ModelAndView saveAddReceiptPage(@ModelAttribute TtAmsReceiptBean receiptBean,BindingResult result,HttpServletRequest request,RedirectAttributes redirectAttributes,HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView("redirect:/account/receipt/receiptPage");
		receiptBean.setIpAddress(request.getRemoteAddr());
		String s = ttAmsReceiptService.saveReceipt(receiptBean);
		if(s==null) {
			redirectAttributes.addFlashAttribute("message", "Sucessfully saved");
			redirectAttributes.addFlashAttribute("messageType", "success");
			redirectAttributes.addFlashAttribute("receiptReportId",receiptBean.getReceiptAmsId());
			System.out.println(receiptBean.getReceiptAmsId());
		}else {
			modelAndView = new ModelAndView("redirect:/account/receipt/addReceipt");
			redirectAttributes.addFlashAttribute("message", s);
			redirectAttributes.addFlashAttribute("messageType", "error");
		}
		return modelAndView;
	}
	
	@ResponseBody
	@RequestMapping(value="/getbankDetails", method=RequestMethod.GET)
	public ResponseEntity<String> getBankDetailsByIfscCode(@RequestParam(value="ifscCode") String ifscCode) {
		String o= ttAmsReceiptService.getBankDetailsByIfsc(ifscCode);
		return ResponseEntity.ok(o);
	}
	
	@RequestMapping(value = "/searchReceipt", method = RequestMethod.GET)
	public ResponseEntity<String> searchReceipt(@RequestParam(name = "module", required = false) String module,
			@RequestParam(name = "receiptType", required = false) String receiptType,
			@RequestParam(name = "fromDate", required = false) String fromDate,
			@RequestParam(name = "toDate", required = false) String toDate,
			@RequestParam(name = "refNo", required = false) String refNo,
			@RequestParam(name = "mobileNo", required = false) String mobileNo) {
		String s = ttAmsReceiptService.searchReceipt(module,receiptType,fromDate,toDate,refNo,mobileNo);
		return ResponseEntity.ok(s);
	}
	
	@RequestMapping(value="/viewReceipt/{receiptNo}", method = RequestMethod.GET)
	public ModelAndView viewReceiptDetails(@PathVariable Long receiptNo) {
		logger.info("View Page for receipt called");
		ModelAndView modelAndView = new ModelAndView(prefixURL+"master-view-receipt-entry");
		modelAndView.addObject("viewBean",ttAmsReceiptService.getViewInformationById(receiptNo));
		return modelAndView;
	}
	
	@RequestMapping(value="/getPaidByList",method=RequestMethod.POST)
	public ResponseEntity<String> getPaidByList(@RequestParam String lookUpValue){
		String[] ss = lookUpValue.split("-");
		String s = ttAmsReceiptService.getPaidByList(ss[0]);
		return ResponseEntity.ok(s);
	}

	@RequestMapping(value = "/accountReceiptReport", method = { RequestMethod.POST, RequestMethod.GET })
	public void AccountReciptReport(@RequestParam("receiptId") Long reciptId, HttpServletResponse response
	/*
	 * @ModelAttribute("propertyDefaulterReport")PropertyDefaulterFilterDto
	 * reportDto
	 */ ) {
		jasperPrint = null;
		HashMap<String, Object> reportParams = new HashMap<String, Object>();
		try {

			List<Object[]> accountReceiprtData = ttAmsReceiptService.getAccountReciptData(getSessionUser().getUlbId(), reciptId);
			AccountReceiptReportHelper reptHelper = new AccountReceiptReportHelper();
			List<AccountReciptSubBean> rptList = reptHelper.getReportLstObj(accountReceiprtData);
			reportParams.put("SUBREPORT_DIR", env.getProperty("jasper.report.path").concat("/water/")); // .concat("treeregsubone.jasper")
			reportParams.put("mahaLogo", env.getProperty("jasper.report.path").concat("/images/maha"));
			reportParams.put("ulblogo", env.getProperty("jasper.report.path").concat("/images/").concat(getSessionUser().getUlbCode().toLowerCase()));
		
			  reportParams.put("ULB_NM",getSessionUser().getUlbName().toUpperCase());
			 

			List<AccountReceiptDetailBean> listaccount = new ArrayList<AccountReceiptDetailBean>();
			AccountReceiptDetailBean accountReceiptDetailBean = new AccountReceiptDetailBean();
			for (int i = 0; i < rptList.size(); i++) {

				accountReceiptDetailBean.setReceiptNumber(rptList.get(i).getReceiptNumber());
				accountReceiptDetailBean.setDepartmentName(rptList.get(i).getDepartmentName());
				accountReceiptDetailBean.setReceiptFor(rptList.get(i).getReceiptFor());
				accountReceiptDetailBean.setNarration(rptList.get(i).getNarration());
				accountReceiptDetailBean.setApplicantName(rptList.get(i).getApplicantName());
				accountReceiptDetailBean.setReceipt_date(rptList.get(i).getReceipt_date());
			}
			accountReceiptDetailBean.setAccountReciptSubBean(rptList);
			listaccount.add(accountReceiptDetailBean);

			JRBeanCollectionDataSource jrbean = new JRBeanCollectionDataSource(listaccount);
			JasperReport jasperFile = jasperReportService.getJasperFile("water", "AccountReciptReport");

			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperFile, reportParams, jrbean); // jrbean //new
																										// JREmptyDataSource()

			jasperReportService.generateReportPDF(response, jasperPrint);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
			

}

