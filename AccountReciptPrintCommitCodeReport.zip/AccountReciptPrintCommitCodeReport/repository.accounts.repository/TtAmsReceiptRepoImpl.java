package com.innowave.mahaulb.repository.accounts.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.innowave.mahaulb.common.dao.TmCmBankBranch;
import com.innowave.mahaulb.common.dao.TmCmLookup;
import com.innowave.mahaulb.common.dao.TmCmLookupDet;
import com.innowave.mahaulb.common.dao.TmCmLookupDetHierarchical;
import com.innowave.mahaulb.common.dao.TmCmModule;
import com.innowave.mahaulb.common.dao.TmCmServices;
import com.innowave.mahaulb.common.dao.views.VtCmHrmsEmployee;
import com.innowave.mahaulb.common.service.beans.UserBean;
import com.innowave.mahaulb.repository.accounts.dao.master.TmAmsBackdatedDays;
import com.innowave.mahaulb.repository.accounts.dao.master.TmAmsUlbBankAccountDet;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsLedger;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsLoan;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceipt;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceiptDet;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceiptMode;

/**
 * @author Mohit
 */

@Transactional
@Repository
public class TtAmsReceiptRepoImpl implements TtAmsReceiptRepo {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private HttpSession httpSession;
	
	private UserBean getUserBean() {
		return (UserBean)httpSession.getAttribute("userBeanObj");
	}
	
	@Override
	public List<Object[]> getReceiptTypeList() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TmCmLookup> rootL = query.from(TmCmLookup.class);
		Root<TmCmLookupDet> rootD = query.from(TmCmLookupDet.class);
		query.multiselect(rootD.get("lookupDetId"),rootD.get("lookupDetDescEn"),rootD.get("lookupDetDescRg"),rootD.get("lookupDetValue"));
		Predicate where = builder.conjunction();
		where = builder.equal(rootL.get("lookupCode"),"RCP");

		where=builder.and(where,builder.equal(rootL.get("lookupId"), rootD.get("tmCmLookup").get("lookupId")));
		query = query.where(where);
		
		Query<Object[]> queryObj=session.createQuery(query);
        List<Object[]> list=queryObj.getResultList();
	    return list;
	}

	@Override
	public List<Object[]> getAdministrationWardList() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TmCmLookup> tmlookup = query.from(TmCmLookup.class);
		Root<TmCmLookupDet> tmlookupdet = query.from(TmCmLookupDet.class);
		Root<TmCmLookupDetHierarchical> tmlookupdether = query.from(TmCmLookupDetHierarchical.class);
		query.multiselect(tmlookupdether.get("lookupDetHierId"),tmlookupdether.get("lookupDetHierDescEn"),
				tmlookupdether.get("lookupDetHierDescRg"),tmlookupdether.get("lookupDetHierValue"));
		Predicate where = builder.conjunction();
		where = builder.equal(tmlookup.get("lookupId"), tmlookupdet.get("tmCmLookup"));
		where = builder.and(where, builder.equal(tmlookupdet.get("lookupDetId"), tmlookupdether.get("tmCmLookupDet")));
		where = builder.and(where, builder.equal(tmlookup.get("lookupCode"), "AWZ"));
		where = builder.and(where, builder.equal(tmlookupdether.get("ulbId"), getUserBean().getUlbId()));
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
        List<Object[]> list=queryObj.getResultList();
	    return list;
	}
	//devendra 
	@Override
	public List<Object[]>getAccountReciptData(int ulbid,Long receiptAmsId)
	{
		
		 
		
	Session session = sessionFactory.getCurrentSession();

	StringBuilder sb=new StringBuilder();
	sb.append(" select Vwaccountreceipt.id.receiptNo,");
	sb.append(" Vwaccountreceipt.id.receivedFrom,Vwaccountreceipt.id.createdDate,Vwaccountreceipt.id.lookupDetDescEnMode,");
	sb.append("Vwaccountreceipt.id.instrumentNo,Vwaccountreceipt.id.instrumentDate ,Vwaccountreceipt.id.bank,Vwaccountreceipt.id.modeAmount,");
	sb.append("Vwaccountreceipt.id.ledgerCode,Vwaccountreceipt.id.ledgerDescription,Vwaccountreceipt.id.ledgerAmount,Vwaccountreceipt.id.modNameEn,Vwaccountreceipt.id.lookupDetDescEn,Vwaccountreceipt.id.receiptRemarks");
	sb.append(" from VwAmsReceiptPrint Vwaccountreceipt  ");
	sb.append(" where Vwaccountreceipt.id.ulbId = :uId ");
	
	sb.append(" and  Vwaccountreceipt.id.receiptAmsId = :reciptId ");
	


			 
	
	String sql=sb.toString();
	Query<Object[]> q =session.createQuery(sql);
	/*Query<Object[]> q =session.createQuery(sql).setMaxResults(5);*/
	q.setParameter("uId", ulbid);
	q.setParameter("reciptId", receiptAmsId);


System.out.println( "query " + q.toString());           

List<Object[]> lst = q.getResultList();
System.out.println( "query------ " + lst);
return lst;

}

	
	@Override
	public List<Object[]> getModuleCode() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TmCmModule> root = query.from(TmCmModule.class);
		query.multiselect(root.get("modId"),root.get("modNameEn"),root.get("modNameRg"),root.get("modCode"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("status"), 1);
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
        List<Object[]> list=queryObj.getResultList();
	    return list;
	}

	@Override
	public List<Object[]> getAccountCode() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TtAmsLedger> root = query.from(TtAmsLedger.class);
		query.multiselect(root.get("ledgerId"),root.get("ledgerCode"),root.get("ledgerDescription"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("status"), 1);
		where = builder.and(where, builder.equal(root.get("tmUlb").get("ulbId"), getUserBean().getUlbId()));
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
        List<Object[]> list=queryObj.getResultList();
	    return list;
	}

	@Override
	public Object[] getAccountCodeName(long ledgerId) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TtAmsLedger> root = query.from(TtAmsLedger.class);
		query.multiselect(root.get("ledgerCode"),root.get("ledgerDescription"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("ledgerId"), ledgerId);
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
		Object[] list=queryObj.getSingleResult();
		return list;
	}
	
	@Override
	public String saveReceipt(TtAmsReceipt amsReceipt) {
		Session session = sessionFactory.getCurrentSession();
		Long i = (long) session.save(amsReceipt);
		return String.valueOf(i);
	}

	@Override
	public String saveReceiptDet(TtAmsReceiptDet amsReceiptDet) {
		Session session = sessionFactory.getCurrentSession();
		session.save(amsReceiptDet);
		return null;
	}

	@Override
	public String saveReceiptMode(TtAmsReceiptMode amsReceiptMode) {
		Session session = sessionFactory.getCurrentSession();
		session.save(amsReceiptMode);
		return null;
	}

	@Override
	public int getLookupDetIdForModeByLookUpCode(String lookupCode) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object> query = builder.createQuery(Object.class);
		Root<TmCmLookupDet> rootDet = query.from(TmCmLookupDet.class);
		Root<TmCmLookup> root = query.from(TmCmLookup.class);
		query.multiselect(rootDet.get("lookupDetId"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("lookupCode"),"PAY");
		where = builder.and(where,builder.equal(rootDet.get("lookupDetValue"), lookupCode));
		where = builder.and(where,builder.equal(rootDet.get("tmCmLookup").get("lookupId"), root.get("lookupId")));
		query = query.where(where);
		Query<Object> queryObj=session.createQuery(query);
		Object o = queryObj.getSingleResult();
		return (int) o;
	}

	@Override
	public int getServiceIdForReceiptVoucher() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object> query = builder.createQuery(Object.class);
		Root<TmCmServices> root = query.from(TmCmServices.class);
		query.multiselect(root.get("serviceId"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("serviceShortCode"),"ARE");
		query = query.where(where);
		Query<Object> queryObj=session.createQuery(query);
		Object o = queryObj.getSingleResult();
		return (int) o;
	}

	@Override
	public List<Object[]> getBankAccountNoList() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TmAmsUlbBankAccountDet> root = query.from(TmAmsUlbBankAccountDet.class);
		query.multiselect(root.get("ublBankAcId"),root.get("acHoNo"),root.get("acHoName"),root.get("tmAmsUlbBankAccount").get("bank"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("status"), 1);
		where = builder.and(where, builder.equal(root.get("ulbId"), getUserBean().getUlbId()));
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
        List<Object[]> list=queryObj.getResultList();
	    return list;
	}

	@Override
	public Object[] getBankDetailsByIfscCode(String ifscCode) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TmCmBankBranch> root = query.from(TmCmBankBranch.class);
		query.multiselect(root.get("bankBranchId"), root.get("bankBranchIfsc"),root.get("bankBranch"),root.get("tmCmBankMaster").get("bank"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("status"), 1);
		where = builder.and(where, builder.equal(root.get("bankBranchIfsc"), ifscCode));
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
		List<Object[]> resultSet=queryObj.getResultList();
        
        if(resultSet != null && !resultSet.isEmpty()) {
        	return resultSet.get(0);
        }
	    return null;
	}
	
	@Override
	public TmAmsUlbBankAccountDet getTmAmsUlbBankAccountDetById(long id) {
		return sessionFactory.getCurrentSession().load(TmAmsUlbBankAccountDet.class, id);
	}

	@Override
	public List<Object[]> searchReceipt(Integer module, Integer receiptType, Date fromDate, Date toDate, String refNo,
			String mobileNo) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TtAmsReceipt> root = query.from(TtAmsReceipt.class);
		query.multiselect(root.get("receiptAmsId"),root.get("receiptNo"),root.get("receiptDate"),root.get("receivedFrom"),root.get("receiptRemarks"));
		Predicate where = builder.conjunction();
		where = builder.notEqual(root.get("receiptDelFlag"), 'D');
		if(module != null && module.compareTo(0)!=0) {
			where = builder.and(where, builder.equal(root.get("modId"), module));
		}
		if(receiptType != null && receiptType.compareTo(0)!=0) {
			where = builder.and(where, builder.equal(root.get("lookupDetIdRcpttype"), receiptType));
		}
		if(fromDate != null) {
			where = builder.and(where, builder.greaterThanOrEqualTo(root.<Date>get("receiptDate"), fromDate));
		}
		if(toDate != null) {
			where = builder.and(where, builder.lessThanOrEqualTo(root.<Date>get("receiptDate"), toDate));
		}
		if(refNo != null && !refNo.isEmpty()) {
			where = builder.and(where, builder.equal(root.get("refNo"), refNo));
		}
		if(mobileNo != null && !mobileNo.isEmpty()) {
			where = builder.and(where, builder.equal(root.get("mobileNo"), mobileNo));
		}
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
		List<Object[]> resultSet=queryObj.getResultList();
		return resultSet;
	}

	@Override
	public TtAmsReceipt getTtAmsReceiptById(long receiptAmsId) {
		return sessionFactory.getCurrentSession().get(TtAmsReceipt.class,receiptAmsId);
	}
	
	@Override
	public Object[] getViewInformation(TtAmsReceipt amsReceipt) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TmCmLookupDet> root = query.from(TmCmLookupDet.class);
		Root<TmCmLookupDetHierarchical> rootH = query.from(TmCmLookupDetHierarchical.class);
		Root<TmCmModule> rootM = query.from(TmCmModule.class);
		
		
		query.multiselect(root.get("lookupDetDescEn"),rootH.get("lookupDetHierDescEn"),rootM.get("modNameEn"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("lookupDetId"), amsReceipt.getLookupDetIdRcpttype());
		where = builder.and(where, builder.equal(rootH.get("lookupDetHierId"), amsReceipt.getLookupDetHierIdAwz1()));
		where = builder.and(where, builder.equal(rootM.get("modId"), amsReceipt.getModId()));
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
		Object[] objects = queryObj.getSingleResult();
		return objects;
	}

	@Override
	public Integer getBackDatedEntryDays() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object> query = builder.createQuery(Object.class);
		Root<TmAmsBackdatedDays> root= query.from(TmAmsBackdatedDays.class);
		query.multiselect(root.get("backdatedaysAllowe"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("tmCmServices").get("serviceId"),getServiceIdForReceiptVoucher());
		where = builder.and(where,builder.equal(root.get("status"), 1));
		where = builder.and(where, builder.equal(root.get("tmUlb").get("ulbId"), getUserBean().getUlbId()));
		query = query.where(where);
		Query<Object> queryObj=session.createQuery(query);
		Object o = null;
		try{
			o= queryObj.getSingleResult();
		}catch(Exception e) {
			return 0;
		}
		if(o == null) {
			return 0;
		}
		return (int) o;
	}

	@Override
	public List<Object[]> getLoanLenderList(int ulbId) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TtAmsLoan> root = query.from(TtAmsLoan.class);
		query.multiselect(root.get("loanId"),root.get("nameOfLender"));
		Predicate where = builder.conjunction();
		where = builder.equal(root.get("status"), 1);
		where = builder.and(where, builder.equal(root.get("tmUlb").get("ulbId"), ulbId));
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
		List<Object[]> resultSet=queryObj.getResultList();
		return resultSet;

	}
	
	@Override
	public List<Object[]> getHrmsEmployeeList(int ulbId) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<VtCmHrmsEmployee> root = query.from(VtCmHrmsEmployee.class);
		query.multiselect(root.get("id").get("hrmsEmpId"),root.get("id").get("empFullName"));
		Predicate where = builder.conjunction();
		//where = builder.equal(root.get("status"), 1);
		where = builder.and(where, builder.equal(root.get("id").get("ulbId"), ulbId));
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
		List<Object[]> resultSet=queryObj.getResultList();
		return resultSet;

	}

	@Override
	public List<Object[]> searchReceiptReversal(Date fromDate, Date toDate, String receiptNumber) {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder builder = session.getCriteriaBuilder();
		CriteriaQuery<Object[]> query = builder.createQuery(Object[].class);
		Root<TtAmsReceipt> root = query.from(TtAmsReceipt.class);
		query.multiselect(root.get("receiptAmsId"),root.get("receiptNo"),root.get("receiptDate"),root.get("receivedFrom"),root.get("receiptRemarks"));
		Predicate where = builder.conjunction();
		where = builder.notEqual(root.get("receiptDelFlag"), 'D');
		if(fromDate != null) {
			where = builder.and(where, builder.greaterThanOrEqualTo(root.<Date>get("receiptDate"), fromDate));
		}
		if(toDate != null) {
			where = builder.and(where, builder.lessThanOrEqualTo(root.<Date>get("receiptDate"), toDate));
		}
		if(receiptNumber != null && !receiptNumber.isEmpty()) {
			where = builder.and(where, builder.equal(root.get("receiptNo"), receiptNumber));
		}
		query = query.where(where);
		Query<Object[]> queryObj=session.createQuery(query);
		List<Object[]> resultSet=queryObj.getResultList();
		return resultSet;
	}

	@Override
	public Long updateReceipt(TtAmsReceipt amsReceipt) {
		try {
			sessionFactory.getCurrentSession().update(amsReceipt);
			return amsReceipt.getReceiptAmsId();
		}catch(Exception e) {
			return null;
		}
		
		
	}
}
