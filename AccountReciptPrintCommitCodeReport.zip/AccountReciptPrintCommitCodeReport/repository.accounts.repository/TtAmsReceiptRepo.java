package com.innowave.mahaulb.repository.accounts.repository;

import java.util.Date;
import java.util.List;

import com.innowave.mahaulb.repository.accounts.dao.master.TmAmsUlbBankAccountDet;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceipt;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceiptDet;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceiptMode;

/**
 * @author Mohit
 */
public interface TtAmsReceiptRepo 
{
	//Method to get Types of Receipt from lookup table
	List<Object[]> getReceiptTypeList();
	
	//Method to get ward List from lookup table based on ulbid
	List<Object[]> getAdministrationWardList();
	//devendra 
	List<Object[]>getAccountReciptData(int ulbid,Long receiptAmsId);
	
	List<Object[]> getModuleCode();
	
	List<Object[]> getAccountCode();
	
	List<Object[]> getBankAccountNoList();
	
	Object[] getBankDetailsByIfscCode(String ifscCode);
	TmAmsUlbBankAccountDet getTmAmsUlbBankAccountDetById(long id);
	String saveReceipt(TtAmsReceipt amsReceipt);
	String saveReceiptDet(TtAmsReceiptDet amsReceiptDet);
	String saveReceiptMode(TtAmsReceiptMode amsReceiptMode);
	Integer getBackDatedEntryDays();
	List<Object[]> searchReceipt(Integer module,Integer receiptType,Date fromDate,Date toDate,String refNo,String mobileNo);
	
	int getLookupDetIdForModeByLookUpCode(String lookupCode);
	int getServiceIdForReceiptVoucher();
	
	TtAmsReceipt getTtAmsReceiptById(long receiptAmsId);

	Object[] getViewInformation(TtAmsReceipt amsReceipt);

	Object[] getAccountCodeName(long ledgerId);

	List<Object[]> getLoanLenderList(int ulbId);

	List<Object[]> getHrmsEmployeeList(int ulbId);
	
	List<Object[]> searchReceiptReversal(Date fromDate,Date toDate, String receiptNumber);
	
	Long updateReceipt(TtAmsReceipt amsReceipt);
}
