package com.innowave.mahaulb.service.accounts.dto.reports;

import java.util.List;

public class AccountReceiptDetailBean {
	List<AccountReciptSubBean> accountReciptSubBean;
	
	public List<AccountReciptSubBean> getAccountReciptSubBean() {
		return accountReciptSubBean;
	}
	public void setAccountReciptSubBean(List<AccountReciptSubBean> accountReciptSubBean) {
		this.accountReciptSubBean = accountReciptSubBean;
	}
	private String receiptNumber;
	private String receipt_date;
	private String departmentName;
	private String applicantName;
	private String narration;
	private String applNumber;
	private String receiptFor;
	private String payAmount;
	private String receiptAmountInWord;
	private String payMode;
	private String instrumentNumber;
	private String instrument_date;
	private String bankBranchName;
	private String fileName;
	private String appDate;
	private String feesName;
	private String	ledgerCode;
	private String ledgerDesc;
	private String 	ledgerAmount;
	private String ledgeAmountTotal;
	public String getLedgeAmountTotal() {
		return ledgeAmountTotal;
	}
	public void setLedgeAmountTotal(String ledgeAmountTotal) {
		this.ledgeAmountTotal = ledgeAmountTotal;
	}
	public String getLedgerCode() {
		return ledgerCode;
	}
	public void setLedgerCode(String ledgerCode) {
		this.ledgerCode = ledgerCode;
	}
	public String getLedgerDesc() {
		return ledgerDesc;
	}
	public void setLedgerDesc(String ledgerDesc) {
		this.ledgerDesc = ledgerDesc;
	}
	public String getLedgerAmount() {
		return ledgerAmount;
	}
	public void setLedgerAmount(String ledgerAmount) {
		this.ledgerAmount = ledgerAmount;
	}
	public String getAppDate() {
		return appDate;
	}
	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}
	public String getFeesName() {
		return feesName;
	}
	public void setFeesName(String feesName) {
		this.feesName = feesName;
	}
	public String getReceiptNumber() {
		return receiptNumber;
	}
	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}
	public String getReceipt_date() {
		return receipt_date;
	}
	public void setReceipt_date(String receipt_date) {
		this.receipt_date = receipt_date;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public String getNarration() {
		return narration;
	}
	public void setNarration(String narration) {
		this.narration = narration;
	}
	public String getApplNumber() {
		return applNumber;
	}
	public void setApplNumber(String applNumber) {
		this.applNumber = applNumber;
	}
	public String getReceiptFor() {
		return receiptFor;
	}
	public void setReceiptFor(String receiptFor) {
		this.receiptFor = receiptFor;
	}
	public String getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(String payAmount) {
		this.payAmount = payAmount;
	}
	public String getReceiptAmountInWord() {
		return receiptAmountInWord;
	}
	public void setReceiptAmountInWord(String receiptAmountInWord) {
		this.receiptAmountInWord = receiptAmountInWord;
	}
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public String getInstrumentNumber() {
		return instrumentNumber;
	}
	public void setInstrumentNumber(String instrumentNumber) {
		this.instrumentNumber = instrumentNumber;
	}
	public String getInstrument_date() {
		return instrument_date;
	}
	public void setInstrument_date(String instrument_date) {
		this.instrument_date = instrument_date;
	}
	public String getBankBranchName() {
		return bankBranchName;
	}
	public void setBankBranchName(String bankBranchName) {
		this.bankBranchName = bankBranchName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

}
