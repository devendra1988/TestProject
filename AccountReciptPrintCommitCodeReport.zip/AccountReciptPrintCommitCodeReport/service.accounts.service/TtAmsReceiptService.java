package com.innowave.mahaulb.service.accounts.service;

import java.util.ArrayList;
import java.util.List;

import com.innowave.mahaulb.common.service.beans.LookupBean;
import com.innowave.mahaulb.portal.utils.StringHelperUtils;
import com.innowave.mahaulb.service.accounts.beans.TtAmsReceiptBankAccountBean;
import com.innowave.mahaulb.service.accounts.beans.TtAmsReceiptBean;

public interface TtAmsReceiptService {

	List<LookupBean> getReceiptTypeBean();
	
	List<LookupBean> getAdministrationWardList();
	
	// for displaying purpose module list is converted into List of lookupbean
	List<LookupBean> getModuleList();
	//devendra 
	List<Object[]>getAccountReciptData(int ulbid,Long receiptAmsId);
	//for displaying 
	List<LookupBean> getAccountCode();
	
	List<TtAmsReceiptBankAccountBean> getBankAccountDetails();
	
	String saveReceipt(TtAmsReceiptBean receiptBean);
	
	String getBankDetailsByIfsc(String ifscCode);
	
	String searchReceipt(String module,String receiptType,String fromDate,String toDate,String refNo,String mobileNo);
	
	Integer getBackDatedEntryDays();

	TtAmsReceiptBean getViewInformationById(long id);
	
	String getPaidByList(String lookUpValue);
	
	String delReceipt(Long id, String delRemarks);

	
	String searchReceiptReversal(String fromDate, String toDate, String receiptNumber);
	
	default List<LookupBean> getLookUpBean(List<Object[]> list){
		List<LookupBean> lookupBeans = new ArrayList<>();
		list.forEach(object -> {
			LookupBean bean = new LookupBean();
			bean.setLookupId(StringHelperUtils.isNullInt((object[0])));
			bean.setLookupDescEn(StringHelperUtils.isNullString((object[1])));
			bean.setLookupDescRg(StringHelperUtils.isNullString((object[2])));
			bean.setLookupCode(StringHelperUtils.isNullString((object[3])));
			lookupBeans.add(bean);
		});
		return lookupBeans;
	}
	
}
