package com.innowave.mahaulb.service.accounts.service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.innowave.mahaulb.common.dao.TmCmBankBranch;
import com.innowave.mahaulb.common.dao.TmCmLookupDet;
import com.innowave.mahaulb.common.service.beans.LookupBean;
import com.innowave.mahaulb.common.service.beans.UserBean;
import com.innowave.mahaulb.portal.utils.DateTimeZoneHelper;
import com.innowave.mahaulb.portal.utils.StringHelperUtils;
import com.innowave.mahaulb.repository.accounts.dao.master.TmAmsUlbBankAccountDet;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceipt;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceiptDet;
import com.innowave.mahaulb.repository.accounts.dao.trans.TtAmsReceiptMode;
import com.innowave.mahaulb.repository.accounts.repo.GetAmsSeqNoRepo;
import com.innowave.mahaulb.repository.accounts.repository.GrantDataEntryRepo;
import com.innowave.mahaulb.repository.accounts.repository.TmAmsVendorRepo;
import com.innowave.mahaulb.repository.accounts.repository.TtAmsReceiptRepo;
import com.innowave.mahaulb.service.accounts.beans.TtAmsReceiptBankAccountBean;
import com.innowave.mahaulb.service.accounts.beans.TtAmsReceiptBean;

/**
 * @author Mohit
 */

@Service
@Transactional
public class TtAmsReceiptServiceImpl implements TtAmsReceiptService {

	@Autowired
	TtAmsReceiptRepo ttAmsReceiptRepo;

	@Autowired
	private HttpSession httpSession;

	@Autowired
	private GetAmsSeqNoRepo getAmsSeqNoRepo;

	@Autowired
	private TmAmsVendorRepo amsVendorRepo;
	
	@Autowired
	GrantDataEntryRepo grantDataEntryRepo;

	private UserBean getUserBean() {
		return (UserBean) httpSession.getAttribute("userBeanObj");
	}

	@Override
	public List<LookupBean> getReceiptTypeBean() {
		return getLookUpBean(ttAmsReceiptRepo.getReceiptTypeList()).stream()
				.filter(bean -> !bean.getLookupCode().equals("BDI")) // as this list should not contain 'Bank Deposit
																		// Interest'
				.collect(Collectors.toList());
	}

	@Override
	public List<LookupBean> getAdministrationWardList() {
		return getLookUpBean(ttAmsReceiptRepo.getAdministrationWardList());
	}

	@Override
	public List<LookupBean> getModuleList() {
		return getLookUpBean(ttAmsReceiptRepo.getModuleCode());
	}
//devendra 
	@Override
	 
	public List<Object[]>getAccountReciptData(int ulbid,Long receiptAmsId)
	{
		return ttAmsReceiptRepo.getAccountReciptData(ulbid,receiptAmsId);
	}
	@Override
	public List<LookupBean> getAccountCode() {
		List<LookupBean> lookupBeans = new ArrayList<>();
		ttAmsReceiptRepo.getAccountCode().forEach(object -> {
			LookupBean bean = new LookupBean();
			bean.setLookupId(getIntegerFromLong(object[0]));
			bean.setLookupDescEn(
					StringHelperUtils.isNullString((object[1])) + "-" + StringHelperUtils.isNullString((object[2])));
			bean.setLookupDescRg(
					StringHelperUtils.isNullString((object[1])) + "-" + StringHelperUtils.isNullString((object[2])));
			lookupBeans.add(bean);
		});
		return lookupBeans;
	}

	private Integer getIntegerFromLong(Object object) {
		try {
			if (object == null) {
				return 0;
			} else {
				Long l = (long) object;
				return l.intValue();
			}
		} catch (NullPointerException n) {
			return 0;
		}
	}

	private String generateSeqNumber(TtAmsReceipt receipt) throws ParseException {
		Date date = DateTimeZoneHelper.getSysDate();
		String seqNo = getAmsSeqNoRepo.getAutoConnectionLoiNo(receipt.getModId(), receipt.getUlbId(), "tt_ams_receipt",
				"receipt_no", 'F', date);
		String ulbShortCode = getAmsSeqNoRepo.getUlbShortsCode(receipt.getUlbId());
		String serCode = getAmsSeqNoRepo.getServShortCode(receipt.getServiceId());
		if (ulbShortCode.length() < 4) {
			ulbShortCode = ulbShortCode + 0;
		}
		if (serCode.length() < 4) {
			serCode = serCode + 0;
		}
		Date fdt = getAmsSeqNoRepo.getFromFinancialDate(date);
		Date tdt = getAmsSeqNoRepo.getFinancialDate(date);
		SimpleDateFormat sm = new SimpleDateFormat("yy");
		String fdtStr = sm.format(fdt);
		String tdtStr = sm.format(tdt);
		String sequenceNo = "00000".substring(seqNo.toString().length()) + seqNo;
		String newReceiptNumber = ulbShortCode + fdtStr + tdtStr + serCode + sequenceNo;
		return newReceiptNumber;
	}

	@Override
	public String saveReceipt(TtAmsReceiptBean receiptBean) {
		if (checkDuplicateLedgerId(receiptBean.getAccountCodeName())) {
			return "Duplicate Account Code Is Not Allowed";
		}
		double sum = 0;
		for (Double d : receiptBean.getAmountEntered()) {
			if (d != null) {
				sum = sum + d;
			}
		}
		receiptBean.setTotalAmount(sum);
		TtAmsReceipt receipt = new TtAmsReceipt();
		receipt.setUlbId(getUserBean().getUlbId());
		receipt.setModId(receiptBean.getModule());
		String[] receiptTypeCode = receiptBean.getReceiptType().split("-");
		receipt.setLookupDetIdRcpttype(Integer.valueOf(receiptTypeCode[1]));

		if (receiptTypeCode[0].equals("MRE")) {
			receipt.setReceivedFrom(receiptBean.getPaidBy());
		} else {
			String[] paidBy = receiptBean.getPaidByName().split("`");
			if (receiptTypeCode[0].equals("ADR")) {
				receipt.setVendorId(Long.valueOf(paidBy[0]));
				receipt.setReceivedFrom(paidBy[1]);
			}
			if (receiptTypeCode[0].equals("CAA")) {
				receipt.setHrmsEmpId(Long.valueOf(paidBy[0]));
				receipt.setReceivedFrom(paidBy[1]);
			}
			if (receiptTypeCode[0].equals("GRA")) {
				receipt.setGrantReceiptId(Long.valueOf(paidBy[0]));
				receipt.setReceivedFrom(paidBy[1]);
			}
			if (receiptTypeCode[0].equals("LON")) {
				receipt.setLoanRecId(Long.valueOf(paidBy[0]));
				receipt.setReceivedFrom(paidBy[1]);
			}
		}

		receipt.setRefNo(receiptBean.getRefNo());
		receipt.setRefDate(convertSimpleDate(receiptBean.getRefDateStr()));
		receipt.setReceiptDate(convertSimpleDate(receiptBean.getReceiptDate()));
		receipt.setMobileNo(receiptBean.getMobileNo());
		receipt.setEmail(receiptBean.getEmailId());
		receipt.setReceiptAmount(receiptBean.getTotalAmount());
		receipt.setLookupDetHierIdAwz1(receiptBean.getLookupDetHierIdAwz1());
		receipt.setCreatedDate(DateTimeZoneHelper.getSysDate());
		receipt.setCreatedBy(getUserBean().getUserId());
		receipt.setInternalReceipt(0l);
		receipt.setServiceId(ttAmsReceiptRepo.getServiceIdForReceiptVoucher());
		receipt.setReceiptRemarks(receiptBean.getNarration());
		receipt.setIpAddress(receiptBean.getIpAddress());
		receipt.setDeviceFrom('C');
		try {
			receipt.setReceiptNo(generateSeqNumber(receipt));
		} catch (ParseException e1) {
			return "Something went wrong!!";

		}

		Set<TtAmsReceiptDet> amsReceiptDets = new HashSet<TtAmsReceiptDet>();
		for (int i = 0; i < receiptBean.getAccountCodeName().size(); i++) {
			TtAmsReceiptDet amsReceiptDet = new TtAmsReceiptDet();
			if (receiptBean.getAccountCodeName().get(i) != null && receiptBean.getAccountCodeName().get(i) != 0) {
				amsReceiptDet.setLedgerId(new Long(receiptBean.getAccountCodeName().get(i)));
				try {
					amsReceiptDet.setLedgerAmount(BigDecimal.valueOf(receiptBean.getAmountEntered().get(i)));
				} catch (Exception e) {
					amsReceiptDet.setLedgerAmount(BigDecimal.ZERO);
				}
				amsReceiptDet.setUlbId(getUserBean().getUlbId());
				amsReceiptDet.setCreatedDate(DateTimeZoneHelper.getSysDate());
				amsReceiptDet.setCreatedBy(getUserBean().getUserId());
				amsReceiptDet.setIpAddress(receiptBean.getIpAddress());
				amsReceiptDet.setDeviceFrom('C');
				amsReceiptDets.add(amsReceiptDet);
			}
		}

		TtAmsReceiptMode amsReceiptMode = new TtAmsReceiptMode();
		amsReceiptMode.setModeAmount(BigDecimal.valueOf(receiptBean.getTotalAmount()));
		amsReceiptMode.setCreatedDate(DateTimeZoneHelper.getSysDate());
		amsReceiptMode.setCreatedBy(getUserBean().getUserId());
		amsReceiptMode.setIpAddress(receiptBean.getIpAddress());
		amsReceiptMode.setDeviceFrom('C');
		TmCmLookupDet cmLookupDet = new TmCmLookupDet();
		cmLookupDet.setLookupDetId(ttAmsReceiptRepo.getLookupDetIdForModeByLookUpCode(receiptBean.getModOfPayment()));
		amsReceiptMode.setTmCmLookupDet(cmLookupDet);
		amsReceiptMode.setUlbId(getUserBean().getUlbId());
		// c means cash
		if (receiptBean.getModOfPayment().equals("C")) {
		} else {
			Object[] obj = ttAmsReceiptRepo.getBankDetailsByIfscCode(receiptBean.getIfscCode());
			TmCmBankBranch bankBranch = new TmCmBankBranch();
			if (obj == null) {
				return "";
			}
			bankBranch.setBankBranchId(StringHelperUtils.isNullInt(obj[0]));
			amsReceiptMode.setTmCmBankBranch(bankBranch);
			amsReceiptMode.setInstrumentNo(receiptBean.getInstrumentNo());
			amsReceiptMode.setInstrumentDate(convertSimpleDate(receiptBean.getInstrumentDateStr()));
			amsReceiptMode.setBank(StringHelperUtils.isNullString(obj[3]));
			amsReceiptMode.setBankBranch(StringHelperUtils.isNullString(obj[2]));
			if (receiptBean.getModOfPayment().equals("POS") || receiptBean.getModOfPayment().equals("B")) {
				TmAmsUlbBankAccountDet accountDet = ttAmsReceiptRepo.getTmAmsUlbBankAccountDetById(Long.valueOf(receiptBean.getBankAccountNo()));
				amsReceiptMode.setUblBankAcId(accountDet.getUblBankAcId());
				amsReceiptMode.setUlbBankAccountName(accountDet.getAcHoName());
				amsReceiptMode.setUlbBankAccountNo(accountDet.getAcHoNo());
				amsReceiptMode.setUlbBankId(accountDet.getTmAmsUlbBankAccount().getUlbBankId());
			}
		}
		receipt.setReceiptDelFlag('N');
		String id = ttAmsReceiptRepo.saveReceipt(receipt);
		receipt.setReceiptAmsId(new Long(id));
		receiptBean.setReceiptAmsId(receipt.getReceiptAmsId());
		amsReceiptDets.forEach(amsReceiptDet -> {
			amsReceiptDet.setTtAmsReceipt(receipt);
			ttAmsReceiptRepo.saveReceiptDet(amsReceiptDet);
		});
		amsReceiptMode.setTtAmsReceipt(receipt);
		ttAmsReceiptRepo.saveReceiptMode(amsReceiptMode);
		return null;
	}

	private Date convertSimpleDate(String date) {
		Date formdate = null;
		try {
			formdate = new SimpleDateFormat("dd/MM/yyyy").parse(date);
		} catch (ParseException e) {
		}
		return formdate;
	}

	private boolean checkDuplicateLedgerId(List<Integer> integers) {
		List<Integer> list = integers.stream().filter(Objects::nonNull).collect(Collectors.toList());
		Set<Integer> s = new HashSet<>(list);
		if (s.size() == list.size()) {
			return false;
		}
		return true;
	}

	@Override
	public List<TtAmsReceiptBankAccountBean> getBankAccountDetails() {
		List<TtAmsReceiptBankAccountBean> accountBeans = new ArrayList<>();
		ttAmsReceiptRepo.getBankAccountNoList().forEach(object -> {
			TtAmsReceiptBankAccountBean accountBean = new TtAmsReceiptBankAccountBean();
			accountBean.setBankAcId(StringHelperUtils.isNullLong((object[0])));
			accountBean.setAccountNumber(StringHelperUtils.isNullString((object[1])));
			accountBean.setAccountName(StringHelperUtils.isNullString((object[2])));
			accountBean.setBank(StringHelperUtils.isNullString((object[3])));
			accountBeans.add(accountBean);
		});
		return accountBeans;
	}

	@Override
	public String getBankDetailsByIfsc(String ifscCode) {

		Object[] lst = ttAmsReceiptRepo.getBankDetailsByIfscCode(ifscCode);
		TtAmsReceiptBean obj = new TtAmsReceiptBean();
		if (lst != null) {
			obj.setBankBranch(StringHelperUtils.isNullString(lst[2]));
			obj.setBankName(StringHelperUtils.isNullString((lst[3])));
		}
		Gson gson = new Gson();
		String str = gson.toJson(obj);
		return str;
	}

	@Override
	public String searchReceipt(String module, String receiptType, String fromDate, String toDate, String refNo,
			String mobileNo) {
		Integer mod = null, rt = null;
		if (module != null && !module.isEmpty()) {
			mod = Integer.parseInt(module);
		}
		if (receiptType != null && !receiptType.isEmpty()) {
			rt = Integer.parseInt(receiptType);
		}
		Date fd = convertSimpleDate(fromDate);
		Date td = convertSimpleDate(toDate);
		List<TtAmsReceiptBean> list = new ArrayList<>();
		ttAmsReceiptRepo.searchReceipt(mod, rt, fd, td, refNo, mobileNo).forEach(object -> {
			TtAmsReceiptBean bean = new TtAmsReceiptBean();
			bean.setReceiptAmsId(StringHelperUtils.isNullLong(object[0]));
			bean.setReceiptNo(StringHelperUtils.isNullString(object[1]));
			bean.setReceiptDate(object[2] != null
					? new SimpleDateFormat("dd/MM/yyyy").format(StringHelperUtils.isNullDate(object[2]))
					: null);
			bean.setPaidBy(StringHelperUtils.isNullString(object[3]));
			bean.setNarration(StringHelperUtils.isNullString(object[4]));
			list.add(bean);
		});
		Gson gson = new Gson();
		String str = gson.toJson(list);
		return str;
	}

	@Override
	public TtAmsReceiptBean getViewInformationById(long id) {
		TtAmsReceipt amsReceipt = ttAmsReceiptRepo.getTtAmsReceiptById(id);
		if(amsReceipt == null || (amsReceipt.getReceiptDelFlag() !=null && amsReceipt.getReceiptDelFlag()  =='D') ) {
			return null;
		}
		Object[] objects = ttAmsReceiptRepo.getViewInformation(amsReceipt);
		TtAmsReceiptBean bean = new TtAmsReceiptBean();
		bean.setReceiptDate(
				new SimpleDateFormat("dd/MM/yyyy").format(StringHelperUtils.isNullDate(amsReceipt.getReceiptDate())));
		bean.setRefNo(amsReceipt.getRefNo());
		bean.setRefDateStr(
				new SimpleDateFormat("dd/MM/yyyy").format(StringHelperUtils.isNullDate(amsReceipt.getRefDate())));
		bean.setPaidBy(amsReceipt.getReceivedFrom());
		bean.setMobileNo(amsReceipt.getMobileNo());
		bean.setEmailId(amsReceipt.getEmail());
		bean.setNarration(amsReceipt.getReceiptRemarks());
		bean.setReceiptTypeStr(StringHelperUtils.isNullString(objects[0]));
		bean.setAdministrationWard(StringHelperUtils.isNullString(objects[1]));
		bean.setModuleStr(StringHelperUtils.isNullString(objects[2]));
		bean.setTotalAmount(amsReceipt.getReceiptAmount());
		Set<TtAmsReceiptMode> set = amsReceipt.getTtAmsReceiptModes();
		set.forEach(action -> {
			bean.setModOfPayment(action.getTmCmLookupDet().getLookupDetValue());
			bean.setIfscCode(
					action.getTmCmBankBranch() != null ? action.getTmCmBankBranch().getBankBranchIfsc() : null);
			bean.setBankName(action.getBank());
			bean.setBranch(action.getBankBranch());
			bean.setInstrumentNo(action.getInstrumentNo());
			bean.setInstrumentDateStr(action.getInstrumentDate() != null
					? new SimpleDateFormat("dd/MM/yyyy").format(action.getInstrumentDate())
					: null);
			bean.setBankAccountName(action.getUlbBankAccountName());
			bean.setBankAccountNo(action.getUlbBankAccountNo());
			return;
		});
		Map<String, Double> map = new HashMap<>();
		Set<TtAmsReceiptDet> dets = amsReceipt.getTtAmsReceiptDets();
		dets.forEach(action -> {
			Object[] obj = ttAmsReceiptRepo.getAccountCodeName(action.getLedgerId());
			String key = StringHelperUtils.isNullString(obj[0]) + "-" + StringHelperUtils.isNullString(obj[1]);
			map.put(key, action.getLedgerAmount().doubleValue());
		});
		bean.setAccountMap(map);
		bean.setReceiptAmsId(amsReceipt.getReceiptAmsId());
		return bean;
	}

	@Override
	public Integer getBackDatedEntryDays() {
		return ttAmsReceiptRepo.getBackDatedEntryDays();
	}

	@Override
	public String getPaidByList(String lookUpValue) {
		List<Object[]> list = new ArrayList<>();
		if (lookUpValue.equals("ADR")) {
			list = amsVendorRepo.getVendorListByUlbid(getUserBean().getUlbId());
		}
		if (lookUpValue.equals("CAA")) {
			list = ttAmsReceiptRepo.getHrmsEmployeeList(getUserBean().getUlbId());
		}
		if (lookUpValue.equals("GRA")) {
			list = grantDataEntryRepo.getGrantListByUlbId(getUserBean().getUlbId());
		}
		if (lookUpValue.equals("LON")) {
			list = ttAmsReceiptRepo.getLoanLenderList(getUserBean().getUlbId());
		}
		List<TtAmsReceiptBean> beans = new ArrayList<>();
		list.forEach(object -> {
			TtAmsReceiptBean receiptBean = new TtAmsReceiptBean();
			receiptBean.setPaidById(StringHelperUtils.isNullLong(object[0]));
			receiptBean.setPaidByName(StringHelperUtils.isNullString(object[1]));
			beans.add(receiptBean);
		});
		Gson gson = new Gson();
		String str = gson.toJson(beans);
		return str;
	}

	@Override
	public String searchReceiptReversal(String fromDate, String toDate, String receiptNumber) {
		Date fd = null,td=null;
		if(fromDate !=null && !fromDate.isEmpty()) {
			fd = convertSimpleDate(fromDate);
		}
		if(toDate !=null && !toDate.isEmpty()) {
			td = convertSimpleDate(toDate);
		}
		List<TtAmsReceiptBean> list = new ArrayList<>();
		ttAmsReceiptRepo.searchReceiptReversal(fd, td, receiptNumber).forEach(object -> {
			TtAmsReceiptBean bean = new TtAmsReceiptBean();
			bean.setReceiptAmsId(StringHelperUtils.isNullLong(object[0]));
			bean.setReceiptNo(StringHelperUtils.isNullString(object[1]));
			bean.setReceiptDate(object[2] != null
					? new SimpleDateFormat("dd/MM/yyyy").format(StringHelperUtils.isNullDate(object[2]))
					: null);
			bean.setPaidBy(StringHelperUtils.isNullString(object[3]));
			bean.setNarration(StringHelperUtils.isNullString(object[4]));
			list.add(bean);
		});
		Gson gson = new Gson();
		String str = gson.toJson(list);
		return str;
	}

	@Override
	public String delReceipt(Long id, String delRemarks) {
		TtAmsReceipt receipt = ttAmsReceiptRepo.getTtAmsReceiptById(id);
		receipt.setReceiptDelFlag('D');
		receipt.setReceiptDelDate(DateTimeZoneHelper.getSysDate());
		receipt.setReceiptDelRemark(delRemarks);
		receipt.setUpdatedBy(getUserBean().getUserId());
		receipt.setUpdatedDate(DateTimeZoneHelper.getSysDate());
		
		Long idR =ttAmsReceiptRepo.updateReceipt(receipt);
		if(idR == null) {
			return "Something Went Wrong";
		}
		return "Successfully Deleted";
	}
}
